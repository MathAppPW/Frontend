import React from "react";
import { useNavigate } from "react-router-dom";

function LeftBar(props) {


  return (
    <>
      <div className="bar-main-menu-small left-bar-main-menu-small"></div>
      <div className="borrder-menu-small right-borrder-menu-top-small"></div>
      <div className="borrder-menu-small right-borrder-menu-bottom-small"></div>
    </>
  );
}

export default LeftBar;
