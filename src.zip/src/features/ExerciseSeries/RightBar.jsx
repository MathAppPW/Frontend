
function RightBar(props){
    

    return(<>

    <div class=" bar-main-menu-small right-bar-main-menu-small"></div>
    <div class="borrder-menu-small left-borrder-menu-top-small"></div>
    <div class="borrder-menu-small left-borrder-menu-bottom-small"></div>    
    </>);
}

export default RightBar;